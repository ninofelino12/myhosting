from setuptools import setup

setup(
    name='felino',
    version='0.1.0',
    description='Deskripsi singkat tentang package',
    author='Nama Anda',
    author_email='email@anda.com',
    url='https://github.com/username/nama_package',
    packages=['felino'],
    install_requires=['odoorpc'],
    python_requires='>=3.6',
)
